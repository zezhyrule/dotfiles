
Inspiration by TobiwanK3nobi
You do not have permission to copy or modify these textures for any purpose.

http://www.minecraftforum.net/topic/402082-32x166-inspiration-by-tobiwank3nobi-new/

INSTALLATION
1. Download the pack from one of the link above.
2. Place the downloaded .zip file in your texture packs folder.
(default:C:\Users\username\AppData\Roaming\.minecraft\texturepacks)
3. Download and install the latest MCPatcher HD Fix. (Do this before you install any other mods)
4. Run Minecraft, select the pack in the MODS AND TEXTURE PACKS menu, load a world, and enjoy. 