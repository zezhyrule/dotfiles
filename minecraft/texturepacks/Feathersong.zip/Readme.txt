FeatherSong v1.0, by Steelfeathers

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Copyright notice: FeatherSong by Steelfeathers is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.

What this means:
1) DO NOT redistribute this pack.
2) DO NOT claim this pack as your own, or put an adfly link on it.
2) DO NOT use textures from this pack in your own work

Feel free to recommend this pack for your map or use it in your videos, however. :)